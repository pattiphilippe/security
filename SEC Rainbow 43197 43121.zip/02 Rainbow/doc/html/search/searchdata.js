var indexSectionsWithContent =
{
  0: "bcdfghimnprs",
  1: "b",
  2: "cgmr",
  3: "cdfghmp",
  4: "cdimns",
  5: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

